# RonoTrade Homepage
Original premium, mobile-first trading homepage for RonoTrade.
Upload these files to the GitHub repository connected to Vercel.

The login/register pages are placeholders. The next step is connecting Supabase Auth and the database. This package is demo/educational and does not process real-money deposits, withdrawals, brokerage orders, or customer funds.
